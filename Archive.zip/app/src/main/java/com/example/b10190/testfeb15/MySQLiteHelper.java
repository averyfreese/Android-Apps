package com.example.b10190.testfeb15;

/**
 * Created by avery on 4/3/16.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MySQLiteHelper extends SQLiteOpenHelper {

    public static final String TABLE_BIRDS = "birds";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_NOTES = "notes";
    public static final String COLUMN_URL = "url";



    private static final String DATABASE_NAME = "birds.db";

    // Database creation sql statement
    private static final String DATABASE_CREATE = "create table "
            + TABLE_BIRDS + "(" + COLUMN_ID
            + " integer primary key autoincrement, " + COLUMN_NAME + " " + COLUMN_DATE + " " +
            COLUMN_TIME + " "+ COLUMN_LOCATION + " "+ COLUMN_NOTES + " "+ COLUMN_URL + ");";

    public MySQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

}