package com.example.b10190.testfeb15;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by avery on 4/3/16.
 */
public class BirdsAdapter extends BaseAdapter {

    ArrayList<BirdObject> birdNames;
    Context mContext;

    BirdsAdapter(Context context) {
        birdNames = new ArrayList<>();
        mContext = context;
    }

    @Override
    public int getCount() {
        return birdNames.size();
    }

    @Override
    public String getItem(int position) {
        return birdNames.get(position).getName();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void setItems(ArrayList<BirdObject> birds) {
        birdNames = birds;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View parentView = inflater.inflate(R.layout.listviewitem, null);

        TextView name = (TextView) parentView.findViewById(R.id.name);
        name.setText(birdNames.get(position).getName());
        return parentView;
    }
}
