package com.example.b10190.testfeb15;

/**
 * Created by avery on 4/3/16.
 */
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class BirdsDataSource {

    // Database fields
    private SQLiteDatabase database;
    private MySQLiteHelper dbHelper;
    private String[] allColumns = { MySQLiteHelper.COLUMN_ID,
            MySQLiteHelper.COLUMN_NAME, MySQLiteHelper.COLUMN_DATE,
            MySQLiteHelper.COLUMN_TIME, MySQLiteHelper.COLUMN_LOCATION,
            MySQLiteHelper.COLUMN_NOTES, MySQLiteHelper.COLUMN_URL};

    public BirdsDataSource(Context context) {
        dbHelper = new MySQLiteHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public BirdObject createBird(String name, String date, String time, String location, String notes, String url) {
        ContentValues values = new ContentValues();
        values.put(MySQLiteHelper.COLUMN_NAME, name);
        values.put(MySQLiteHelper.COLUMN_DATE, date);
        values.put(MySQLiteHelper.COLUMN_TIME, time);
        values.put(MySQLiteHelper.COLUMN_LOCATION, location);
        values.put(MySQLiteHelper.COLUMN_NOTES, notes);
        values.put(MySQLiteHelper.COLUMN_URL, url);

        long insertId = database.insert(MySQLiteHelper.TABLE_BIRDS, null, values);
        Cursor cursor = database.query(MySQLiteHelper.TABLE_BIRDS, allColumns,
                MySQLiteHelper.COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        BirdObject bird = cursorToBird(cursor);
        cursor.close();
        return bird;
    }

    public void deleteBird(long id) {
        System.out.println("Comment deleted with id: " + id);
        database.delete(MySQLiteHelper.TABLE_BIRDS, MySQLiteHelper.COLUMN_ID
                + " = " + id, null);
    }

    public ArrayList<BirdObject> getAllBirds() {
        ArrayList<BirdObject> birds = new ArrayList<BirdObject>();

        Cursor cursor = database.query(MySQLiteHelper.TABLE_BIRDS,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            BirdObject bird = cursorToBird(cursor);
            birds.add(bird);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        return birds;
    }

    private BirdObject cursorToBird(Cursor cursor) {
        BirdObject comment = new BirdObject();
        comment.setId(cursor.getLong(0));
        comment.setName(cursor.getString(1));
        comment.setDate(cursor.getString(2));
        comment.setTime(cursor.getString(3));
        comment.setLocation(cursor.getString(4));
        comment.setNotes(cursor.getString(5));
        return comment;
    }

    public void createBird(String name, String date, String time, String location, String notes) {
    }
}
