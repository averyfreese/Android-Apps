package com.example.b10190.testfeb15;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class addActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bird_sightings);

    }

}
