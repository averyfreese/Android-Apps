package com.example.b10190.testfeb15;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;

import java.util.ArrayList;

public class BirdsViewActivity extends AppCompatActivity {
    Button button_Add;
    ListView birdsList;
    BirdsAdapter birdsAdapter;
    private BirdsDataSource dataSource;
    ArrayList<BirdObject> birds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataSource = new BirdsDataSource(this);


        setContentView(R.layout.birds_view_activity);
        button_Add = (Button) findViewById(R.id.buttonAdd);
        birdsList = (ListView) findViewById(R.id.birdsList);

        birdsAdapter = new BirdsAdapter(this);
        birdsList.setAdapter(birdsAdapter);

        button_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(BirdsViewActivity.this, BirdSightings.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        dataSource.open();
        birds = dataSource.getAllBirds();
        birdsAdapter.setItems(birds);
        birdsAdapter.notifyDataSetChanged();

        birdsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(BirdsViewActivity.this, BirdSightings.class);
                BirdObject bird = birds.get(position);
                i.putExtra("name",bird.getName() );
                i.putExtra("date", bird.getDate());
                i.putExtra("time", bird.getTime());
                i.putExtra("location", bird.getLocation());
                i.putExtra("notes", bird.getNotes());
                i.putExtra("id", bird.getId());
                startActivity(i);
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        dataSource.close();
    }
}
