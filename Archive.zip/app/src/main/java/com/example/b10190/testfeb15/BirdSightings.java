package com.example.b10190.testfeb15;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BirdSightings extends AppCompatActivity {
    private EditText editTextE;
    private EditText editText2E;
    private EditText editText5E;
    private EditText editText4E;
    private EditText editText3E;
    private Button buttonSave;
    private Button buttonCancel;

    private BirdsDataSource dataSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bird_sightings);
        dataSource = new BirdsDataSource(this);
        dataSource.open();

        String name = getIntent().getStringExtra("name");
        String date = getIntent().getStringExtra("date");
        String time = getIntent().getStringExtra("time");
        String location = getIntent().getStringExtra("location");
        String notes = getIntent().getStringExtra("notes");
        long id = getIntent().getLongExtra("id", 0);



        editTextE = (EditText) findViewById(R.id.editTextE);
        editText2E = (EditText) findViewById(R.id.editText2E);
        editText5E = (EditText) findViewById(R.id.editText5E);
        editText4E = (EditText) findViewById(R.id.editText4E);
        editText3E = (EditText) findViewById(R.id.editText3E);
        buttonSave = (Button) findViewById(R.id.buttonSave);


        if ( name != null && !name.isEmpty()) {
            editTextE.setText(name);
            editText5E.setText(date);
            editText4E.setText(time);
            editText3E.setText(location);
            editText2E.setText(notes);
        }

        buttonCancel = (Button) findViewById(R.id.buttonCancel);
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Name = editTextE.getText().toString();
                String Date = editText2E.getText().toString();
                String Time = editText5E.getText().toString();
                String Location = editText4E.getText().toString();
                String Notes = editText3E.getText().toString();
                dataSource.createBird(Name, Date, Time, Location, Notes);

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        dataSource.open();
    }

    @Override
    public void onPause() {
        super.onPause();
        dataSource.close();
    }
}
