package com.example.b10190.testfeb15;

import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class ContentViewActivity extends AppCompatActivity {

    TextView description;
    TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_view_acitivity);

        name = (TextView) findViewById(R.id.birdName);
        description = (TextView) findViewById(R.id.editText3);

        String nameS = getIntent().getStringExtra("name");
        String descriptionS = getIntent().getStringExtra("description");

        name.setText(nameS);
        description.setText(descriptionS);
    }

}
