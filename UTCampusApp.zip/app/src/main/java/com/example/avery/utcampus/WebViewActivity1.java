package com.example.avery.utcampus;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebViewActivity1 extends Activity {

    private WebView webView1;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        webView1 = (WebView) findViewById(R.id.webView1);

        webView1.getSettings().setJavaScriptEnabled(true);

        webView1.loadUrl("https://www.utexas.edu/maps/main/buildings/cba.html");

        //String customHtml = "<html><body><h2>Greetings from JavaCodeGeeks</h2></body></html>";
        //webView.loadData(customHtml, "text/html", "UTF-8");

    }

}
