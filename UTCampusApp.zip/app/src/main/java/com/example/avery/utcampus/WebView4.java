package com.example.avery.utcampus;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebView4 extends Activity {

    private WebView webView4;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view4);

        webView4 = (WebView) findViewById(R.id.webView4);

        webView4.getSettings().setJavaScriptEnabled(true);

        webView4.loadUrl("https://www.utexas.edu/maps/main/buildings/std.html");


    }

}
