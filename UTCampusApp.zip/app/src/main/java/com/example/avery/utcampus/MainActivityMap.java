package com.example.avery.utcampus;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;
        import java.util.List;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
        import android.widget.AdapterView.OnItemSelectedListener;

public class MainActivityMap extends AppCompatActivity implements OnItemSelectedListener{
    private MediaPlayer mediaPlayer;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_map);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        spinner.setOnItemSelectedListener(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.buildings, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);

    }
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
        if (item.equals("PCL")) {
            Intent i = new Intent(MainActivityMap.this, WebView2.class);
            startActivity(i);
        }
        if (item.equals("McCombs")) {
            Intent i = new Intent(MainActivityMap.this, WebViewActivity1.class);
            startActivity(i);

        }
        if (item.equals("UT Tower")) {
            Intent i = new Intent(MainActivityMap.this, WebView3.class);
            startActivity(i);

        }
        if (item.equals("Darrell K Royal Stadium")) {
            Intent i = new Intent(MainActivityMap.this, WebView4.class);
            startActivity(i);

        }
        if (item.equals("CPE")) {
            Intent i = new Intent(MainActivityMap.this, WebView5.class);
            startActivity(i);

        }
        if (item.equals("UT Fight Song")) {
            MediaPlayer mPlayer = MediaPlayer.create(this, R.raw.ut_fight);
            mPlayer.start();        }
    }


    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub
    }
}
