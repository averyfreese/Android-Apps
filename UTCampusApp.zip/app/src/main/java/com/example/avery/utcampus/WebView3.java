package com.example.avery.utcampus;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebView3 extends Activity {

    private WebView webView3;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view3);

        webView3 = (WebView) findViewById(R.id.webView3);

        webView3.getSettings().setJavaScriptEnabled(true);

        webView3.loadUrl("https://www.utexas.edu/maps/main/buildings/mai.html");


    }

}
