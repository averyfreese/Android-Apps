package com.example.avery.utcampus;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebView2 extends Activity {

    private WebView webView2;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view2);

        webView2 = (WebView) findViewById(R.id.webView2);

        webView2.getSettings().setJavaScriptEnabled(true);

        webView2.loadUrl("https://www.utexas.edu/maps/main/buildings/pcl.html");


    }

}
