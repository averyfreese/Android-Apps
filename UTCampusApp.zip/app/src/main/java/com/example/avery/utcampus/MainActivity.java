package com.example.avery.utcampus;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    private Button buttonNext;
    private Button buttonVid;
    VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonNext = (Button) findViewById(R.id.buttonNext);
        buttonVid = (Button) findViewById(R.id.buttonVid);
        getWindow().setFormat(PixelFormat.UNKNOWN);
        VideoView videoView = (VideoView)findViewById(R.id.videoView);
        String uriPath2 = "android.resources://com.example.toyo.playvideo/"+R.raw.welcome_video_android_phone;
        Uri uri2 = Uri.parse(uriPath2);
        videoView.setVideoURI(uri2);
        videoView.requestFocus();
        videoView.start();

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MainActivityMap.class);
                startActivity(i);
            }

        });
        buttonVid.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                VideoView videoView = (VideoView) findViewById(R.id.videoView);
                String uriPath = "android.resource://com.example.toyo.playvideo/" + R.raw.welcome_video_android_phone;
                Uri uri2 = Uri.parse(uriPath);
                videoView.setVideoURI(uri2);
                videoView.requestFocus();
                videoView.start();
            }


        });
    }
}
