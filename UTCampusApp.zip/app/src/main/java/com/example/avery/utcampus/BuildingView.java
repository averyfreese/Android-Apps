package com.example.avery.utcampus;

import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class BuildingView extends AppCompatActivity {

    ImageView image;
    TextView description;
    TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_building_view);
        image = (ImageView) findViewById(R.id.buildingImage);
        name = (TextView) findViewById(R.id.buildingName);
        description = (TextView) findViewById(R.id.buildingNotes);

        String nameS = getIntent().getStringExtra("name");
        String descriptionS = getIntent().getStringExtra("description");
        int imageId = getIntent().getIntExtra("image", 0);

        Drawable drawable = getResources().getDrawable(imageId);
        image.setImageDrawable(drawable);
        name.setText(nameS);
        description.setText(descriptionS);
    }

}