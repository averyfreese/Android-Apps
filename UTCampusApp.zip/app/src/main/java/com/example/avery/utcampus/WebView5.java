package com.example.avery.utcampus;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebView5 extends Activity {

    private WebView webView5;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        webView5 = (WebView) findViewById(R.id.webView5);

        webView5.getSettings().setJavaScriptEnabled(true);

        webView5.loadUrl("https://www.utexas.edu/maps/main/buildings/cpe.html");

    }

}
